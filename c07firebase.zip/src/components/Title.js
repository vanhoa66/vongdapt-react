import React, { Component } from 'react';

class Title extends Component {
    render() {
        return (
            <div className="page-header">
                <h1>Project 05 - Task Manager <small>React Redux Router Firebase</small></h1>
            </div>
        );
    }
}

export default Title;


