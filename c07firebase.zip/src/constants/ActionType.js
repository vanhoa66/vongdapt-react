
export const CHANGE_NOTIFY 		= 'CHANGE_NOTIFY';
export const HIDE_NOTIFY 		= 'HIDE_NOTIFY';
export const USER_LOGIN 		= 'USER_LOGIN';
export const USER_LOGOUT 		= 'USER_LOGOUT';